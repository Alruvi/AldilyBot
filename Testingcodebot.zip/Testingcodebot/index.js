const qrcode = require("qrcode-terminal");
const moment = require("moment");
const cheerio = require("cheerio");
const get = require('got')
const fs = require("fs");
const dl = require("./lib/downloadImage.js");
const fetch = require('node-fetch');
const urlencode = require("urlencode");
const axios = require("axios");
const imageToBase64 = require('image-to-base64');
const menu = require("./lib/menu.js");
const donate = require("./lib/donate.js");
const info = require("./lib/info.js");
//
const BotName = 'Aldaily Bot'; // Nama Bot.      BOT BY Aldaily Bot 
const instagram = 'https://instagram.com/alruviworld'; // Instagram
const whatsapp = 'wa.me/+6283818127405'; // Nomor Kontak
const kapanbotaktif = 'Kapan Saja'; // Status Onlime Bot
//
const
{
   WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   waChatKey,
} = require("@adiwajshing/baileys");
var jam = moment().format("HH:mm");

// OCR Library
const readTextInImage = require('./lib/ocr')

function foreach(arr, func)
{
   for (var i in arr)
   {
      func(i, arr[i]);
   }
}
const conn = new WAConnection()
conn.on('qr', qr =>
{
   qrcode.generate(qr,
   {
      small: true
   });
   console.log(`[ ${moment().format("HH:mm:ss")} ] Silahkan Scan Qr`);
});

conn.on('credentials-updated', () =>
{
   // save credentials whenever updated
   console.log(`credentials updated!`)
   const authInfo = conn.base64EncodedAuthInfo() // get all the auth info we need to restore this session
   fs.writeFileSync('./session.json', JSON.stringify(authInfo, null, '\t')) // save this info to a file
})
fs.existsSync('./session.json') && conn.loadAuthInfo('./session.json')
// uncomment the following line to proxy the connection; some random proxy I got off of: https://proxyscrape.com/free-proxy-list
//conn.connectOptions.agent = ProxyAgent ('http://1.0.180.120:8080')
conn.connect();

conn.on('user-presence-update', json => console.log(`[ ${moment().format("HH:mm:ss")} ] =>  bot by @maslent`))
conn.on('message-status-update', json =>
{
   const participant = json.participant ? ' (' + json.participant + ')' : '' // participant exists when the message is from a group
   console.log(`[ ${moment().format("HH:mm:ss")} ] =>  bot by @AldailyBot`)
})

conn.on('message-new', async(m) =>
{
   const messageContent = m.message
   const text = m.message.conversation
   let id = m.key.remoteJid
   const messageType = Object.keys(messageContent)[0] // message will always contain one key signifying what kind of message
   let imageMessage = m.message.imageMessage;
   console.log(`[ ${moment().format("HH:mm:ss")} ] => Nomor: [ ${id.split("@s.whatsapp.net")[0]} ] => ${text}`);
   
   switch (prefix) {
   case 'menu':
   client.sendMessage(id, menu.menu(id, BotName, tanggal, waktu, instagram, whatsapp, ontime), MessageType.text)
   break
   case 'info':
   client.sendMessage(id, info.info(id, BotName, tanggal, waktu, instagram, whatsapp, ontime), MessageType.text)
   break
   case 'donate':
   client.sendMessage(id, donasi.donasi(id, BotName, tanggal, waktu, instagram, whatsapp, ontime), MessageType.text)
   break
   case 'nulis':
   nulis(value)
   .then(data => {
   client.sendMessage(id, '[ WAIT ] Sedang di proses⏳ silahkan tunggu sebentar', MessageType.text)
   client.sendMessage(id, data, MessageType.image)
   })
   .catch(err => {
   console.log(err)
   })
   break
   case 'sticker':
   const image = await client.downloadAndSaveMediaMessage(m)
   exec('cwebp -q 50 ' + image + ' -o temp/' + time + '.webp', (error, stdout, stderr) => {
   let result = fs.readFileSync('temp/' + time + '.webp')
   client.sendMessage(id, result, MessageType.sticker)
   })
   break
   case 'say':
   await client.sendMessage(id, value, MessageType.text)
   break
   case 'sholat':
   jsholat(value)
   .then(data => {
   const { Imsyak, Subuh, Dzuhur, Ashar, Maghrib, Isya, Dhuha } = data
   let hasil = `Jadwal sholat di *${value}* hari ini adalah\n\n⚡Imsyak : ${Imsyak}\n⚡Subuh : ${Subuh} WIB\n⚡Dzuhur : ${Dzuhur}WIB\n⚡Ashar : ${Ashar} WIB\n⚡Maghrib : ${Maghrib}\n⚡Isya : ${Isya} WIB\n⚡Tengah malam : ${Dhuha} WIB`
   client.sendMessage(id, hasil, MessageType.text)
   })
   .catch(err => {
   console.log(err)
   })
   break
   case 'quran':
   surah()
   .then(data => {
   const re = /{(.*?)}/gi
   const { acak, surat } = data
   
   const keterangan = acak.id.ayat.replace(re, '')
   const arText = acak.ar.teks
   const idText = acak.id.teks
   const surah= surat.nama
   
   let hasil = `[${keterangan}]   ${arText}\n\n${idText}(QS.${surah}, Ayat ${keterangan})`;
   client.sendMessage(id, hasil, MessageType.text);
   })
   .catch(err => {
   console.log(err)
   })
   break
   case 'pantun':
   pantun()
   .then(data => {
   client.sendMessage(id, data, MessageType.text)
   })
   .catch(err => {
   console.log(err)
   })
   break
   case 'quotes':
   quotes()
   .then(data => {
   const { author, quotes } = data
   let hasil = `_${quotes}_\n\n~${author}`
   client.sendMessage(id, hasil, MessageType.text)
   })
   .catch(err => {
   console.log(err)
   })
   break
   case 'nama':
   artinama(value)
   .then(data => {
   const { result: arti } = data
   let hasil = `\nArti nama mu adalah\n\n***********************************\n\n       _${value}_ ${arti}\n\n***********************************`
   client.sendMessage(id, hasil, MessageType.text)
   })
   .catch(err => {
   console.log(err)
   })
   break
   case 'pasangan':
   jodoh(value)
   .then(data => {
   const { positif, negatif } = data
   const nama = value.split(/[\&\-\/\+]/)
   let hasil = `\nKecocokan jodoh\n\n************************************\n\nPasangan 1: *${nama[0].trim()}*\nPasangan 2: *${nama[1].trim()}*\n\nsisi positif: ${positif}\nsisi negatif: ${negatif}\n\n***********************************`
   client.sendMessage(id, hasil, MessageType.text)
   })
   .catch(err => {
   console.log(err)
   })
   break
   case 'pict':
   switch (value) {
   case 'cewek':
   cewePict()
   .then(buffer => {
   client.sendMessage(id, '[ WAIT ] Sedang di proses⏳ silahkan tunggu sebentar', MessageType.text)
   client.sendMessage(id, buffer, MessageType.image)
   })
   .catch(err => {
   console.log(err)
   })
   break
   case 'cowok':
   cowoPict()
   .then(buffer => {
   client.sendMessage(id, '[ WAIT ] Sedang di proses⏳ silahkan tunggu sebentar', MessageType.text)
   client.sendMessage(id, buffer, MessageType.image)
   })
   .catch(err => {
   console.log(err)
   })
   break
   default:
   client.sendMessage(id, 'ulangi dengan  !pict cewek/cowok\n\nMisal: !pict cowok', MessageType.text)
   break
   }
   break
  if (text.includes("!randomanime"))
  {
  var items = ["anime girl", "anime cantik", "anime", "anime aesthetic"];
  var cewe = items[Math.floor(Math.random() * items.length)];
  var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
  
  axios.get(url)
  .then((result) => {
  var b = JSON.parse(JSON.stringify(result.data));
  var cewek =  b[Math.floor(Math.random() * b.length)];
  imageToBase64(cewek) // Path to the image
  .then(
  (response) => {
  var buf = Buffer.from(response, 'base64'); // Ta-da	
  conn.sendMessage(
  id,
  buf,MessageType.image)
  
  }
  )
  .catch(
  (error) => {
  console.log(error); // Logs an error if there was one
  }
  )
  
  });
  })
   .catch(err => {
   console.log(err)
   })
   break
   case 'lirik':
   lirik(value)
   .then(data => {
   const { hasil: lirik } = data
   let hasil = `📍lirik lagu📍 *${value}* \n\n\n${lirik}`
   client.sendMessage(id, hasil, MessageType.text)
   })
   .catch(err => {
   console.log(err)
   })
   break
   case 'alay':
   alay(value)
   .then(data => {
   const { hasil: alay } = data
   client.sendMessage(id, alay, MessageType.text)
   })
   .catch(err => {
   console.log(err)
   })
   break
   case 'ocr':
   const media = await client.downloadAndSaveMediaMessage(m)
   readTextInImage(media)
   .then(data => {
   client.sendMessage(id, `*Read Data Text in Image* \n\nHasil: \n\n${data}`, MessageType.text);
   })
   .catch(err => {
   console.log(err)
   })
   break
   default:
   break
   }
   }) //End Script